
package com.mycompany.animalobj;
public class Mammal extends Animal
{
    
}
