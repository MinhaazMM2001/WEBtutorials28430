
package com.mycompany.animalobj;
public class Reptile extends Animal
{
    
}
