
package com.mycompany.animalobj;
public class Animal 
{
  

}
