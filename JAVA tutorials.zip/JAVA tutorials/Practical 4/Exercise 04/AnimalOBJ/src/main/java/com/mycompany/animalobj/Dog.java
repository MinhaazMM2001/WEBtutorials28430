
package com.mycompany.animalobj;
public class Dog extends Mammal
{
    
}
