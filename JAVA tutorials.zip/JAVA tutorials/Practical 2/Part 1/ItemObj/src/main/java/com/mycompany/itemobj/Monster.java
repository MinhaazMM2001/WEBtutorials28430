
package com.mycompany.itemobj;
public class Monster extends Item
{
    public void Monster(int location,String description)
    {
        super(location,description);
    }
}
