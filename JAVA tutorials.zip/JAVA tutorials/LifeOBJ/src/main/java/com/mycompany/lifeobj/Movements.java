
package com.mycompany.lifeobj;
public abstract class Movements
{
    protected int sp;
   public abstract void MoveUp(); 
   public abstract void MoveDown(); 
   public abstract void MoveLeft(); 
   public abstract void MoveRight();

}
