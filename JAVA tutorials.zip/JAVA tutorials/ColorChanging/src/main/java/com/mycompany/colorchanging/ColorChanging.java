
package com.mycompany.colorchanging;
public class ColorChanging 
{

    public static void main(String[] args) 
    {
        ColorDemo c=new ColorDemo();
        c.show();
    }
}
