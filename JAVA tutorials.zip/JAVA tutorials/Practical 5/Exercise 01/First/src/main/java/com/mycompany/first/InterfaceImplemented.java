
package com.mycompany.first;
public class InterfaceImplemented implements MyFirstInterface
{
    @Override
    public void display()
    {
        int x=10;
        System.out.println("Value of x is"+x);
    }
}
