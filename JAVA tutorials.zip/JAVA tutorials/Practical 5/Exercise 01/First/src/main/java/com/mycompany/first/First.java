
package com.mycompany.first;
public class First
{

    public static void main(String[] args) 
    {
        InterfaceImplemented i=new InterfaceImplemented();
        i.display();
    }
}
