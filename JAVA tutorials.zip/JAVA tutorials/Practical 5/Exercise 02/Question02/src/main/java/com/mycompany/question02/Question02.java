package com.mycompany.question02;
public class Question02 
{

    public static void main(String[] args) 
    {
         Lecturer L1=new Lecturer();
       L1.speak();
       Politician P1=new Politician();
       P1.speak();
       Priest PR1=new Priest();
       PR1.speak();
    }
}
