
package com.mycompany.question02;
public class Lecturer implements Speaker
{
    @Override
    public void speak()
    {
        System.out.println("Good MORNING");
    }
}
