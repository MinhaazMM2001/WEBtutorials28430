
package com.mycompany.question02;
public class Politician implements Speaker
{ 
    @Override
  public void speak() 
    {
        System.out.println("Hello");
    }
    
}
