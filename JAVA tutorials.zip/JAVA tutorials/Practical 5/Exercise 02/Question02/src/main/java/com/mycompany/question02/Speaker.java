
package com.mycompany.question02;
public interface Speaker 
{
    void speak();
}
