
package com.mycompany.studentobj;
public class StudentObj {

    public static void main(String[] args) 
    {
        Undergraduate U1=new Undergraduate();
       U1.display();
    }
}
