
package com.mycompany.studentobj;
public class Undergraduate extends Student
{
    
}
