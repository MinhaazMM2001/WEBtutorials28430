
package com.mycompany.shapeobj;
public abstract class Shape

{
    abstract double calculateArea();
    public void display()
{
System.out.println("Shape :");
}
}

