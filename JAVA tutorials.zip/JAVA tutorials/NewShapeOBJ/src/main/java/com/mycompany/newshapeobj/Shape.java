
package com.mycompany.newshapeobj;
public interface Shape 
{
     public abstract double calculateArea();
     public abstract double calculatePerimeter();
}
