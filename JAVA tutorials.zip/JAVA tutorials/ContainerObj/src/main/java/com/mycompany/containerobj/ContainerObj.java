package com.mycompany.containerobj;
public class ContainerObj 
{

    public static void main(String[] args) 
    {
        CylindercalContainer container=new  CylindercalContainer();
        
    }
}
