/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.guiclick;

/**
 *
 * @author kanna
 */
public class GuiClick {

    public static void main(String[] args) 
    {
        Click c=new Click();
        c.show();
    }
}
