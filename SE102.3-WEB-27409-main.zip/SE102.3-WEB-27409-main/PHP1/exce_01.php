<!-- http://localhost/PHP1/exce_01.php -->

<?php
// Create variables and assign values
$x = 6;
$y = 4;

// Perform operations
$sum_result = $x + $y;
$difference_result = $x - $y;
$product_result = $x * $y;
$division_result = $x / $y;

// Display the results
echo "Sum : " . $sum_result . "\n";
echo "Difference : " . $difference_result . "\n";
echo "Product : " . $product_result . "\n";
echo "Division : " . $division_result . "\n";
?>